<?php

$method = $_SERVER['REQUEST_METHOD'];

// Veritabanı bağlantısını içe aktar
require_once('dbbaglanti.php');

// Personel ekleme işlemi yapan API
if ($_GET['action'] == 'ekle_personel') {
    if ($method == 'POST') {
        $isim = $_POST['isim'];
        $telefon = $_POST['telefon'];
        $mail = $_POST['mail'];
        $pozisyon = $_POST['pozisyon'];

        $stmt = $conn->prepare("CALL PersonelEkle(?, ?, ?, ?)");
        $stmt->bindParam(1, $isim, PDO::PARAM_STR);
        $stmt->bindParam(2, $telefon, PDO::PARAM_STR);
        $stmt->bindParam(3, $mail, PDO::PARAM_STR);
        $stmt->bindParam(4, $pozisyon, PDO::PARAM_STR);

        if ($stmt->execute()) {
            echo "Personel başarıyla eklendi.";
        } else {
            echo "Personel eklenirken bir hata oluştu.";
        }
    } else {
        echo "Geçersiz istek yöntemi.";
    }
}

// Personel güncelleme işlemi yapan API
else if ($_GET['action'] == 'guncelle_personel') {
    if ($method == 'PUT') {
        $put_vars = json_decode(file_get_contents("php://input"), true);

        $personelID = $put_vars['personelID'];
        $isim = $put_vars['isim'];
        $telefon = $put_vars['telefon'];
        $mail = $put_vars['mail'];
        $pozisyon = $put_vars['pozisyon'];

        $stmt = $conn->prepare("CALL PersonelGuncelle(?, ?, ?, ?, ?)");
        $stmt->bindParam(1, $personelID, PDO::PARAM_INT);
        $stmt->bindParam(2, $isim, PDO::PARAM_STR);
        $stmt->bindParam(3, $telefon, PDO::PARAM_STR);
        $stmt->bindParam(4, $mail, PDO::PARAM_STR);
        $stmt->bindParam(5, $pozisyon, PDO::PARAM_STR);

        if ($stmt->execute()) {
            echo "Personel başarıyla güncellendi.";
        } else {
            echo "Personel güncellenirken bir hata oluştu.";
        }
    } else {
        echo "Geçersiz istek yöntemi.";
    }
}

// Personel silme işlemi yapan API
else if ($_GET['action'] == 'sil_personel') {
    if ($method == 'DELETE') {
        $data = json_decode(file_get_contents("php://input"), true);

        $personelID = $data['personelID'];

        $stmt = $conn->prepare("CALL PersonelSil(?)");
        $stmt->bindParam(1, $personelID, PDO::PARAM_INT);

        if ($stmt->execute()) {
            echo "Personel başarıyla silindi.";
        } else {
            echo "Personel silinirken bir hata oluştu.";
        }
    } else {
        echo "Geçersiz istek yöntemi.";
    }
}

// Personelleri getirme işlemi yapan API
else if ($_GET['action'] == 'getir_personeller') {
    if ($method == 'GET') {
        $result = $conn->query("CALL PersonelGetir()");

        if ($result->rowCount() > 0) {
            $personeller = array();
            while ($row = $result->fetchAll(PDO::FETCH_ASSOC)) {
                $personeller[] = $row;
            }
            echo json_encode($personeller);
        } else {
            echo "Personel bulunamadı.";
        }
    } else {
        echo "Geçersiz istek yöntemi.";
    }
}

?>
